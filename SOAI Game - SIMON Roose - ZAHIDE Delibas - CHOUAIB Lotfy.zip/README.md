# SO &amp; Ai: Untitled fight game
Github repo voor de pygame project van SO &amp; Ai 2025

Voorlopig staat alles nog in main.py maar de bedoeling is om later elk blok code die een bepaalde functie heeft een aparte file te geven en dan alles roepen (met import ...) in een nieuwe main die als startfile zou dienen.

Zie misschien deze spel (de fnaf waarover assistent het heeft) om een goed idee te hebben van wat ik bedoel: https://github.com/eldek0/fnaf-in-pygame/tree/master?tab=readme-ov-file
